#pragma once
#include "Tablero.h"
#include "PalabrasComprobar.h"
#include "Jugadores.h"
#include "Palabras.h"

class Juego
{
private:
	Tablero* tablero; 
	PalabrasComprobar palabrasComprobar;
	Jugadores* jugadores; 


};

